package LinkedListSet;

import LinkedList.Collection;

public interface Set<E> extends Collection<E>{

}
