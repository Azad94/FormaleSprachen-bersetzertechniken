package ast;

import lexer_parser.Token;

public class IDNode extends AtomicNode {

	public IDNode(Token token) {
		super(token);
	}

}
