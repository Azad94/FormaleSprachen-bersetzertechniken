package ast;

import lexer_parser.Token;

public class IntNode extends AtomicNode {

	public IntNode(Token token) {
		super(token);
	}

}
