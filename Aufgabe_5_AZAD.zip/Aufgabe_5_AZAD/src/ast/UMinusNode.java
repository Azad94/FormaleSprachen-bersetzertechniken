package ast;

import lexer_parser.Token;

public class UMinusNode extends UnaryNode {

	public UMinusNode(ExprNode left, Token token) {
		super(left, token);
	}

}