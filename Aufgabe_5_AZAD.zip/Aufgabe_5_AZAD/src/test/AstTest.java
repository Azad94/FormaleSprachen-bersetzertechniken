package test;

import org.junit.Test;
import static org.junit.Assert.*;
import ast.HeteroAST;
import lexer_parser.*;

public class AstTest {

	@Test
	public void test() {
		Lexer lexer = new RecDesLexer("3+2*7-2\n");
		RecDesParser parser = new RecDesParser(lexer);
		HeteroAST ast = parser.statlist();
		System.out.println(ast.toStringTree());
		
	}
}