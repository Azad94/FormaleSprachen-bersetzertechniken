package test;

import static org.junit.Assert.*;

import org.junit.Test;

import ast.HeteroAST;
import lexer_parser.*;
import visitor.*;

public class VisitorTest {

	@Test
	public void testByNode() {
		Lexer lexer = new RecDesLexer(" 3 + 4 + 5 * (5 / #4)\n");
		RecDesParser parser = new RecDesParser(lexer);
		HeteroAST ast = parser.statlist();
		
				
		IndepInorderPrintVisitor visitor = new IndepInorderPrintVisitor(true);
		IndepEvalVisitor evaluator = new IndepEvalVisitor(true);
		
		System.out.println(visitor.print(ast)+" = "+ evaluator.eval(ast));		
		//Ergebnus: 0,75
		
		//-------------------
		lexer = new RecDesLexer(" 3 + #4 + 5 \n");
		parser = new RecDesParser(lexer);
		ast = parser.statlist();
					
		System.out.println(visitor.print(ast)+" = "+ evaluator.eval(ast));		
	}
	
	@Test
	public void testByToken() {
		Lexer lexer = new RecDesLexer(" 3 + 4 + 5 * (5 / #4)\n");
		RecDesParser parser = new RecDesParser(lexer);
		HeteroAST ast = parser.statlist();
		
				
		IndepInorderPrintVisitor visitor = new IndepInorderPrintVisitor(false);
		IndepEvalVisitor evaluator = new IndepEvalVisitor(false);
		
		System.out.println(visitor.print(ast)+" = "+ evaluator.eval(ast));		
		//Ergebnis: 0,75
		
		//-------------------
		lexer = new RecDesLexer(" 3 + #4 + 5 \n");
		parser = new RecDesParser(lexer);
		ast = parser.statlist();
					
		System.out.println(visitor.print(ast)+" = "+ evaluator.eval(ast));		
	}
	
}